public class Funcionario {

    private int codigo;
    private String nome;
    private String endereco;

}
