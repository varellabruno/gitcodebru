public class Produto {

    private int codigo;
    private String nome;

}
