public class Bicicleta {

    //classe para cadastro e controle de biciletas

    private int codigo;

    private int tamanhoQuadro;

    private int tamanhoAro;

    private String cor;

    private char eletrica;

    private char marcha;



    public int getTamanhoQuadro() {
        return tamanhoQuadro;
    }

    public void setTamanhoQuadro(int tamanhoQuadro) {
        this.tamanhoQuadro = tamanhoQuadro;
    }

    public int getTamanhoAro() {
        return tamanhoAro;
    }

    public void setTamanhoAro(int tamanhoAro) {
        this.tamanhoAro = tamanhoAro;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }


    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public char getEletrica() {
        return eletrica;
    }

    public void setEletrica(char eletrica) {
        this.eletrica = eletrica;
    }

    public char getMarcha() {
        return marcha;
    }

    public void setMarcha(char marcha) {
        this.marcha = marcha;
    }
}
