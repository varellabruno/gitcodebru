public class PrimeiraClasse {

    public static void main(String args[]) {
        System.out.println("Olá, Bruno");
        Bicicleta bicicleta = new Bicicleta();

        bicicleta.setCodigo(1);
        System.out.println(bicicleta.getCodigo());
        bicicleta.setCor("Azul");
        System.out.println(bicicleta.getCor());
        bicicleta.setTamanhoAro(20);
        System.out.println(bicicleta.getTamanhoAro());
        bicicleta.setTamanhoQuadro(26);
        System.out.println(bicicleta.getTamanhoQuadro());
        bicicleta.setEletrica('S');
        System.out.println(bicicleta.getEletrica());
        bicicleta.setMarcha('S');
        System.out.println(bicicleta.getMarcha());



    }
}
